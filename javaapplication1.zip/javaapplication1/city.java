package javaapplication1;

import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;  
import org.hibernate.service.ServiceRegistry;

/**
 *
 * @author Wassay
 */

public class city {  
	String id,country,region,city,postalCode,latitude,longitude,metroCode,areaCode;
        
        String getid(){return id;}
        void setid(String a){ this.id=a;}
        
        String getcountry(){return country;}
        void setcountry(String b){ this.country=b;}
        
        String getregion(){return region;}
        void setregion(String c){ this.region=c;}
        
        String getcity(){return city;}
        void setcity(String d){ this.city=d;}
        
        String getpostalCode(){return postalCode;}
        void setpostalCode(String e){ this.postalCode=e;}
        
        String getlatitude(){return latitude;}
        void setlatitude(String f){ this.latitude=f;}
        
        String getlongitude(){return longitude;}
        void setlongitude(String g){ this.longitude=g;}
        
        String getmetroCode(){return metroCode;}
        void setmetroCode(String h){ this.metroCode=h;}
        
        String getareaCode(){return areaCode;}
        void setareaCode(String i){ this.areaCode=i;}
        

}