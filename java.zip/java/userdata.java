import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Wassay
 */

@Entity
@Table(name = "USERDATA")
public class userdata {
    @Id
    String userid;
    String scheme;
    float time;
    
    public void setuserid(String a){this.userid=a;}
    public String getuserid(){return userid;}
    
    public void setscheme(String b){this.scheme=b;}
    public String getscheme(){return scheme;}
    
    public void settime(float c){this.time=c;}
    public float gettime(){return time;}
}
