
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.IOException;
/**
 *
 * @author Wassay
 */
public class readdata {
    public static  String read(){
        String csvFile = "C:\\Users\\Wassay\\Desktop\\Gtest_two-anon.csv";

        String line = "";
        String cvsSplit = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {
                Passwords P = new Passwords();

                String[] pass = line.split(cvsSplit);  // use comma as separator

                P.setuserid(Integer.valueOf(pass[0].toString()));
                P.setscheme(pass[1].toString());
                P.settime(pass[2].toString());
                P.setstate(pass[3].toString());
                P.sett1(pass[4].toString());
                P.setstate1(pass[5].toString());
                P.sett2(pass[6].toString());
                P.setstate2(pass[7].toString());
                P.sett3(pass[8].toString());
                P.setstate3(pass[9].toString());
                P.sett4(pass[10].toString());
                P.setstate4(pass[11].toString());
                P.sett5(pass[12].toString());
                P.setstate5(pass[13].toString());
                P.sett6(pass[14].toString());
                P.setstate6(pass[15].toString());
                P.sett7(pass[16].toString());
                P.setstate7(pass[17].toString());
                
                
                


                session.persist(P);//persisting the object


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    
    
    }
     
  
    public static void main(String[] args) {
        // TODO code application logic here
             
    
    }
}
