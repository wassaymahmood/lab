package dao;
import java.util.ArrayList;
import model.userdata;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;


/**
 *
 * @author Wassay
 */
public class Dao {
    public Session currSession = null;
	public Dao(){
		HibernateUtil.createSessionFactory();
		currSession=HibernateUtil.getSessionFactory().openSession();  
	}
	public void finalize(){
		currSession.close();}
        
        public void save(ArrayList<userdata> newEmpList){
		Transaction t=currSession.beginTransaction();  
      		for(int i=0;i<newEmpList.size();i++){
			currSession.persist((userdata)newEmpList.get(i));
		}
      		t.commit(); 
 	}
	public void printEmployees(){
		Query query=currSession.createQuery("from Employee");  
    		List <userdata> list=query.list();  
      
   		Iterator <userdata> itr=list.iterator();  
		while(itr.hasNext()){  
			userdata emp=itr.next();  
			System.out.println("Emp Name: "+emp.getFirstName());  
    		}  
	}


}
