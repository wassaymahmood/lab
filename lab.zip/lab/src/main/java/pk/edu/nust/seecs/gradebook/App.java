package pk.edu.nust.seecs.gradebook;
import BOs.CloBO;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;

/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    public static void main(String[] args) {
        CloBO cl = new CloBO();
        

        // Add new clo
        Clo clo = new Clo();
        Resource r=new ClassPathResource("applicationContext.xml");
        BeanFactory factory=new XmlBeanFactory(r);
        clo=(Clo)factory.getBean("Clo");
        
        cl.addClo(clo);

        // Delete an existing clo
        //dao.deleteClo(1);

        // Get all clos
        
    }
}