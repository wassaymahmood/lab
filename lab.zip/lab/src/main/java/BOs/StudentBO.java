/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BOs;
import pk.edu.nust.seecs.gradebook.dao.StudentDao;
import pk.edu.nust.seecs.gradebook.entity.Student;
/**
 *
 * @author Wassay
 */
public class StudentBO {
    StudentDao Student=new StudentDao();
    
    public void addStudent(Student student){
        Student.addStudent(student);
    }
    
    public void updateStudent(Student student){
        Student.updateStudent(student);
    }
}
