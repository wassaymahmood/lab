/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BOs;
import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;

public class CloBO {
    CloDao Clo= new CloDao();
    
    public void addClo(Clo clo){
        Clo.addClo(clo);
    }
    
    public void updateClo(Clo clo){
        Clo.updateClo(clo);
}
}