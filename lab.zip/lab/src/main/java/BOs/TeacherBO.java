/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BOs;
import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Teacher;

/**
 *
 * @author Wassay
 */
public class TeacherBO {
    TeacherDao Teacher=new TeacherDao();
    
    public void addTeacher(Teacher teacher){
        Teacher.addTeacher(teacher);
    }
    
     public void updateTeacher(Teacher teacher){
         Teacher.updateTeacher(teacher);
}
}
