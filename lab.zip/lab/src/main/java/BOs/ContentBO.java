/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BOs;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.entity.Content;
/**
 *
 * @author Wassay
 */
public class ContentBO {
    ContentDao Content=new ContentDao();
    
    public void addContent(Content content){
        Content.addContent(content);
    }
    
    public void updateContent(Content content){
        Content.updateContent(content);
}}
